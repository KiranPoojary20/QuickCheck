-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2023 at 11:10 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quickcheck`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `a_id` int(11) NOT NULL,
  `aname` varchar(50) NOT NULL,
  `password` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`a_id`, `aname`, `password`) VALUES
(1, 'admin', '$2y$10$GrU8geT26gfsh1ZlWauQtuUoHY/S96mRzr8pq8coQNuuwVvVfg9O6');

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `bid` int(11) NOT NULL,
  `bname` varchar(30) NOT NULL,
  `bdate` datetime NOT NULL DEFAULT current_timestamp(),
  `bstatus` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`bid`, `bname`, `bdate`, `bstatus`) VALUES
(1, 'Toyoto', '2023-05-19 11:05:05', ''),
(2, 'Ford', '2023-05-19 11:05:34', ''),
(3, 'Toyota', '2023-05-19 11:06:00', ''),
(4, 'BMW', '2023-05-19 11:06:29', ''),
(5, 'Nissan', '2023-05-19 11:06:56', ''),
(6, 'BMW', '2023-05-19 11:11:07', '');

-- --------------------------------------------------------

--
-- Table structure for table `emissiontest`
--

CREATE TABLE `emissiontest` (
  `e_id` int(11) NOT NULL,
  `ename` varchar(100) NOT NULL,
  `euname` varchar(50) NOT NULL,
  `e_phone` bigint(10) NOT NULL,
  `e_address` varchar(150) NOT NULL,
  `e_details` varchar(300) NOT NULL,
  `password` varchar(250) NOT NULL,
  `e_email` varchar(50) NOT NULL,
  `e_date` datetime NOT NULL DEFAULT current_timestamp(),
  `e_stauts` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `emissiontest`
--

INSERT INTO `emissiontest` (`e_id`, `ename`, `euname`, `e_phone`, `e_address`, `e_details`, `password`, `e_email`, `e_date`, `e_stauts`) VALUES
(1, 'Elon Emission center', 'Elon', 6787900876, 'mumbai', 'Vehicle emissions control is the study of reducing the emissions produced by motor vehicles, especially internal combustion engines.', '$2y$10$5zftGycH0I1KPzG1zhlX/eRQgK42veOgEwx29TaOLIMG4UvDI6gCO', 'Elon@gmail.com', '2023-07-05 12:27:45', '');

-- --------------------------------------------------------

--
-- Table structure for table `insurance`
--

CREATE TABLE `insurance` (
  `i_id` int(5) NOT NULL,
  `iname` varchar(100) NOT NULL,
  `iuname` varchar(50) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(150) NOT NULL,
  `details` varchar(200) NOT NULL,
  `password` varchar(250) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `status` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `insurance`
--

INSERT INTO `insurance` (`i_id`, `iname`, `iuname`, `phone`, `email`, `address`, `details`, `password`, `date`, `status`) VALUES
(1, 'Quick Insurance', 'Salam', 6768977654, 'salam@gmail.com', 'Bangalore', 'Commercial Vehicle Insurance Policy by HDFC ERGO helps organization cover financial loss arising of accident or damage to your commercial vehicle.', '$2y$10$GrU8geT26gfsh1ZlWauQtuUoHY/S96mRzr8pq8coQNuuwVvVfg9O6', '2023-07-05 12:24:24', '');

-- --------------------------------------------------------

--
-- Table structure for table `model`
--

CREATE TABLE `model` (
  `mid` int(11) NOT NULL,
  `bid` int(11) NOT NULL,
  `mname` varchar(40) NOT NULL,
  `mdate` datetime NOT NULL DEFAULT current_timestamp(),
  `mstatus` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `model`
--

INSERT INTO `model` (`mid`, `bid`, `mname`, `mdate`, `mstatus`) VALUES
(1, 2, 'Golf', '2023-05-19 11:05:48', ''),
(2, 3, 'F-Series', '2023-05-19 11:06:16', ''),
(3, 4, 'Focus', '2023-05-19 11:06:40', ''),
(4, 5, 'Go+', '2023-05-19 11:07:15', '');

-- --------------------------------------------------------

--
-- Table structure for table `owner`
--

CREATE TABLE `owner` (
  `o_id` int(11) NOT NULL,
  `oname` varchar(50) NOT NULL,
  `ophone` bigint(10) NOT NULL,
  `oemail` varchar(50) NOT NULL,
  `regno` varchar(90) NOT NULL,
  `oaddress` varchar(150) NOT NULL,
  `password` varchar(250) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `status` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `owner`
--

INSERT INTO `owner` (`o_id`, `oname`, `ophone`, `oemail`, `regno`, `oaddress`, `password`, `date`, `status`) VALUES
(1, 'vedhanth', 8798788765, 'vedhanth@gmail.com', 'KA 12 E 2865', 'Mangalore', '$2y$10$uuqcbKPscdjsSndEjY9bcu1Avy/kT0e9O9/XlSFZzwGP4xrcc/zv2', '2023-07-02 09:56:59', ''),
(2, 'puneeth', 8152077321, 'puneeth@gmail.com', 'KA 12 E 1785', 'Uppinangady', '$2y$10$uuqcbKPscdjsSndEjY9bcu1Avy/kT0e9O9/XlSFZzwGP4xrcc/zv2', '2023-07-02 10:02:32', '');

-- --------------------------------------------------------

--
-- Table structure for table `traffic_police`
--

CREATE TABLE `traffic_police` (
  `p_id` int(11) NOT NULL,
  `stname` varchar(50) NOT NULL,
  `pname` varchar(50) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(150) NOT NULL,
  `password` varchar(250) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `status` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `traffic_police`
--

INSERT INTO `traffic_police` (`p_id`, `stname`, `pname`, `phone`, `email`, `address`, `password`, `date`, `status`) VALUES
(1, 'Police Station', 'Manju', 8767544543, 'manju@gmail.com', 'Mangalore', '$2y$10$ndQiQJ91AeFg1UN4Ho8b0u4gk1AfdLv6F6andoaZjexuIu1./d1Au', '2023-07-05 12:22:31', '');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `v_id` int(11) NOT NULL,
  `vc_id` int(11) NOT NULL,
  `bid` int(11) NOT NULL,
  `mid` int(11) NOT NULL,
  `p_id` int(50) NOT NULL,
  `regno` varchar(90) NOT NULL,
  `regdate` date NOT NULL,
  `oname` varchar(50) NOT NULL,
  `iamount` float NOT NULL,
  `ename` varchar(50) NOT NULL,
  `edate` date NOT NULL,
  `iname` varchar(50) NOT NULL,
  `idate` date NOT NULL,
  `qrcode` varchar(700) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `istatus` varchar(150) NOT NULL,
  `estatus` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`v_id`, `vc_id`, `bid`, `mid`, `p_id`, `regno`, `regdate`, `oname`, `iamount`, `ename`, `edate`, `iname`, `idate`, `qrcode`, `date`, `istatus`, `estatus`) VALUES
(1, 2, 2, 1, 1, 'KA 12 E 2865', '2023-07-02', 'Vedhanth', 2000, 'Elon Emission center', '2023-06-26', 'Quick Insurance', '2023-06-26', 'qcode1299960296.png', '2023-07-02 08:18:30', 'reneval required', 'Expired'),
(2, 2, 3, 2, 1, 'KA 12 E 1785', '2023-07-01', 'Puneeth', 0, 'Elon Emission center', '2023-06-28', '', '0000-00-00', 'qcode.rand().png', '2023-07-02 09:59:41', '', 'Emission done');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_category`
--

CREATE TABLE `vehicle_category` (
  `vc_id` int(11) NOT NULL,
  `vname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vehicle_category`
--

INSERT INTO `vehicle_category` (`vc_id`, `vname`) VALUES
(1, '2 wheeler'),
(2, '4 wheeler'),
(3, '6 wheeler'),
(4, '3 wheeler');

-- --------------------------------------------------------

--
-- Table structure for table `vemission`
--

CREATE TABLE `vemission` (
  `ve_id` int(11) NOT NULL,
  `bid` int(10) NOT NULL,
  `mid` int(10) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `e_id` int(10) NOT NULL,
  `oname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `regno` varchar(50) NOT NULL,
  `edate` date NOT NULL,
  `eamount` float NOT NULL,
  `estatus` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vemission`
--

INSERT INTO `vemission` (`ve_id`, `bid`, `mid`, `cat_id`, `e_id`, `oname`, `email`, `regno`, `edate`, `eamount`, `estatus`) VALUES
(1, 2, 1, 2, 1, 'Vedhanth', 'vedhanth@gmail.com', 'KA 12 E 2865', '2023-06-26', 1000, 'Expired'),
(2, 3, 2, 2, 1, 'Puneeth', 'puneeth@gmail.com', 'KA 12 E 1785', '2023-06-28', 2000, 'Emission done');

-- --------------------------------------------------------

--
-- Table structure for table `vinsurance`
--

CREATE TABLE `vinsurance` (
  `vi_id` int(11) NOT NULL,
  `bid` int(10) NOT NULL,
  `mid` int(10) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `i_id` int(10) NOT NULL,
  `oname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `regno` varchar(80) NOT NULL,
  `idate` date NOT NULL,
  `amount` int(100) NOT NULL,
  `status` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vinsurance`
--

INSERT INTO `vinsurance` (`vi_id`, `bid`, `mid`, `cat_id`, `i_id`, `oname`, `email`, `regno`, `idate`, `amount`, `status`) VALUES
(1, 2, 1, 2, 1, 'Vedhanth', 'vedhanth@gmail.com', 'KA 12 E 2865', '2023-06-26', 2000, 'reneval required');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `emissiontest`
--
ALTER TABLE `emissiontest`
  ADD PRIMARY KEY (`e_id`);

--
-- Indexes for table `insurance`
--
ALTER TABLE `insurance`
  ADD PRIMARY KEY (`i_id`);

--
-- Indexes for table `model`
--
ALTER TABLE `model`
  ADD PRIMARY KEY (`mid`),
  ADD KEY `bid` (`bid`);

--
-- Indexes for table `owner`
--
ALTER TABLE `owner`
  ADD PRIMARY KEY (`o_id`);

--
-- Indexes for table `traffic_police`
--
ALTER TABLE `traffic_police`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`v_id`);

--
-- Indexes for table `vehicle_category`
--
ALTER TABLE `vehicle_category`
  ADD PRIMARY KEY (`vc_id`);

--
-- Indexes for table `vemission`
--
ALTER TABLE `vemission`
  ADD PRIMARY KEY (`ve_id`);

--
-- Indexes for table `vinsurance`
--
ALTER TABLE `vinsurance`
  ADD PRIMARY KEY (`vi_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `a_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `emissiontest`
--
ALTER TABLE `emissiontest`
  MODIFY `e_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `insurance`
--
ALTER TABLE `insurance`
  MODIFY `i_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `model`
--
ALTER TABLE `model`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `owner`
--
ALTER TABLE `owner`
  MODIFY `o_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `traffic_police`
--
ALTER TABLE `traffic_police`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `vehicle`
--
ALTER TABLE `vehicle`
  MODIFY `v_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `vehicle_category`
--
ALTER TABLE `vehicle_category`
  MODIFY `vc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `vemission`
--
ALTER TABLE `vemission`
  MODIFY `ve_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `vinsurance`
--
ALTER TABLE `vinsurance`
  MODIFY `vi_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `model`
--
ALTER TABLE `model`
  ADD CONSTRAINT `model_ibfk_1` FOREIGN KEY (`bid`) REFERENCES `brand` (`bid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
