<nav class="navbar navbar-expand-lg navbar-light px-4 px-lg-5 py-3 py-lg-0">
                <a href="index.html" class="navbar-brand p-0">
                    <h1 class="m-0">QuickCheck</h1>
                    <!-- <img src="img/logo.png" alt="Logo"> -->
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="fa fa-bars"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav ms-auto py-0">
                        <a href="index.php" class="nav-item nav-link active">Home</a>
                        <!-- <a href="about.php" class="nav-item nav-link">About</a> -->
                        <?php 
                        if(isset($_SESSION['oid'])){
                        ?>
                        <a href="view_detail.php" class="nav-item nav-link">Service</a>
                        <!-- <a href="profile.php" class="nav-item nav-link">Profile</a> -->
                        <?php } ?>
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                            <div class="dropdown-menu m-0">
                                <?php 
                               if(!isset($_SESSION['oid'])){

                                ?>
                                <a href="register.php" class="dropdown-item">Register</a>
                                <a href="login.php" class="dropdown-item">Login</a>
                                <?php }else{ ?>
                                <a href="controller/logout.php" class="dropdown-item">Logout</a>
                                <?php } ?>
                            </div>
                        </div>
                        <!-- <a href="contact.php" class="nav-item nav-link">Contact</a> -->
                    
            </nav>