<?php 


define('DIR','../');
require_once DIR . 'config.php';
$control = new Controller();
$admin = new Admin();

 	include "qrlib.php";
 	if(isset($_POST['create']))
 	{
 		$qc =  $_POST['qrContent'];
 		$qrUname = $_POST['qrUname'];
 		
 	
 		$final = $qc.$qrUname;



        $qrImgName = "qcode".rand();

      
               
        
                $qrimage = $qrImgName.".png";
 		

 		 $stmt = $admin -> cud("INSERT INTO `qrcodes` ( `qrUsername`, `qrContent`, `qrImg`) 
                 VALUES ('".$qc."','".$qrUname."','".$qrimage."')","saved");

 	}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Qr Gen</title>
	<link rel="stylesheet" href="">
</head>
<body>
<a href="qcode2046065191.png" download>down</a>

	 <form action="" method="POST">
            <div class="form-group">
                <label for="exampleInputEmail1">Your Name</label>
                <input type="text" name="qrContent" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Your Name">
           </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Contant</label>
                <input type="text" name="qrUname" class="form-control" id="exampleInputPassword1" placeholder="Enter Content">
            </div>
         
            <input name="create" value="Genarate" type="submit" class="btn btn-primary">
        </form>
	

</body>
</html>