<?php
 include '../config.php';
 $admin= new Admin();
   if(isset($_SESSION['aid'])){
   	session_destroy();
   	unset($_SESSION['aid']);
   	 $admin -> redirect('signin');
   }
 ?>