
<?php

define('DIR', '../../');
require_once DIR .'config.php';

$control = new Controller(); 
$admin = new Admin();

include "../../readerlib/qrlib.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer.php';
require 'SMTP.php';
require 'Exception.php';

require 'vendor/autoload.php';

$mail = new PHPMailer(true);

try {
    //Server settings Signed out
 

if(isset($_POST['add']))
{

  $email=$_POST['e'];
  $name=$_POST['n'];
  

 $a=$_POST['a'];



  $s=$_POST['s'];




  $stmtt=$admin->ret("SELECT * from `vehicle`
   INNER JOIN `brand` ON brand.bid=vehicle.bid 
   INNER JOIN `model` ON model.mid=vehicle.mid WHERE `regno`='$a'");
  $row = $stmtt->fetch(PDO::FETCH_ASSOC);
 
            $bid=$row['bid'];
            $mid=$row['mid'];
            $vc_id=$row['vc_id'];
            $regno=$row['regno'];
            $regdate=$row['regdate'];
            $oname=$row['oname'];

            $ename=$row['ename'];
            $edate=$row['edate'];
            $estatus=$row['estatus'];


            $iname=$row['iname'];
            $idate=$row['idate'];
            $iamount=$row['iamount'];





  $tot="vechile Catagory:".$vc_id."\r\n"."Brand:".$bid."\r\n"."Model:".$mid."\r\n"."Registration Number:".$regno."\r\n"."Registration Date:".$regdate."\r\n"."Owner name:".$oname."\r\n"."Insurance:".$iname."\r\n"."Insurance Amount:".$iamount."\r\n"."Insurance date:".$idate."\r\n"."Insurance Status:".$s."\r\n"."Emission:".$ename."\r\n"."Emission date:".$edate."\r\n"."Emission Status:".$estatus;
   


        $qrImgName = "qcode".rand();


                $qrs = QRcode::png($tot,"../controller/qcodes/$qrImgName.png","H","3","3");
        
                $qrimage = $qrImgName.".png";





   $stmt=$admin -> cud("UPDATE `vehicle` SET `istatus`='$s',`qrcode`='$qrimage' WHERE `regno`='$a'","updated");


    $stmtj=$admin -> cud("UPDATE `vinsurance` SET `status`='$s' WHERE `regno`='$a'","updated");

 


    $mail->isSMTP();                                            // Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 'amexiqinfo@gmail.com';                     // SMTP username
    $mail->Password   = 'gcmlepkietirnokq';                               // SMTP password
    $mail->SMTPSecure = 'ssl';;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
    $mail->Port       = 465;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

    //Recipients
    $mail->setFrom('amexiqinfo@gmail.com', 'admin');
    $mail->addAddress($email,$name);

    // Content
    $mail->isHTML(true);
    $mail->Subject = 'this is subject';
    $mail->Body    = 'Dear coustemer your Insurance '.$s;
   
     
    // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    // $mail->AddEmbeddedImage($image); 

    $mail->send();

     //what you should do after sending mail
    echo"<script>
            alert('Your notification is sent sucessfully!!!');
            window.location.href='../view_insurance.php';
          </script>";

    exit();

}

} catch (Exception $e) {
  
  //error if somthing went wrong

  echo "<script>alert('Message could not be sent.');window.location.href='../view_insurance.php';</script>";
}
?>
