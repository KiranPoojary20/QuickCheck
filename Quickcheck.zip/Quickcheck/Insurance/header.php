<!-- Navbar Start -->
            <nav class="navbar navbar-expand bg-secondary navbar-dark sticky-top px-4 py-0">
                <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
                    <h2 class="text-primary mb-0"><i class="fa fa-user-edit"></i></h2>
                </a>
                <a href="#" class="sidebar-toggler flex-shrink-0">
                    <i class="fa fa-bars"></i>
                </a>
               
                <div class="navbar-nav align-items-center ms-auto">
                   
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                           <?php 
                            if(isset($_SESSION['iid'])){
                    $iid=$_SESSION['iid'];
                    $stmt=$admin->ret("SELECT * FROM `insurance` WHERE `i_id`='$iid'");
                                $row=$stmt->fetch(PDO::FETCH_ASSOC);
?>
                           
                            <span class="d-none d-lg-inline-flex"><?php echo $row['iname'] ?></span>
                            <?php }elseif(isset($_SESSION['eid'])){
                     $eid=$_SESSION['eid'];
                    $stmt=$admin->ret("SELECT * FROM `emissiontest` WHERE `e_id`='$eid'");
                    $row=$stmt->fetch(PDO::FETCH_ASSOC);

                    ?>
                                                <span class="d-none d-lg-inline-flex"><?php echo $row['ename'] ?></span>
                                                <?php }elseif(isset($_SESSION['pid'])){
                     $eid=$_SESSION['pid'];
                    $stmt=$admin->ret("SELECT * FROM `traffic_police` WHERE `p_id`='$pid'");
                    $row=$stmt->fetch(PDO::FETCH_ASSOC);

                    ?>      
                                                <span class="d-none d-lg-inline-flex"><?php echo $row['stname'] ?></span>
<?php } ?>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-secondary border-0 rounded-0 rounded-bottom m-0">
                            <!-- <a href="signin.php" class="dropdown-item">Login</a> -->
                          
                            <!-- <a href="signin.php " class="dropdown-item">Signin</a> -->
                            <a href="Controller/logout.php " class="dropdown-item">Log Out</a>
                        </div>
                    </div>
                </div>
            </nav>
            <!-- Navbar End -->