<?php
include '../../config.php';
$admin=new Admin();
if(isset($_POST['signin'])){
	$name=$_POST['name'];
	$password=$_POST['password'];
	$stmt=$admin->ret("SELECT * FROM `insurance` WHERE `iname`='$name'");
	$num=$stmt->rowCount();
	if($num>0){
		$row=$stmt->fetch(PDO::FETCH_ASSOC);
		$dbpassword=$row['password'];
		if(password_verify($password,$dbpassword)){
			$_SESSION['iid']=$row['i_id'];
		echo "<script>alert('Login Successfull');window.location='../index.php';</script>";
		}else{
			echo "<script>alert('You have entered wrong password');window.location='../signin.php';</script>";

		}
	}else{
		// echo "<script>alert('You are not valid user');window.location='../signin.php';</script>";

	
	$stmt=$admin->ret("SELECT * FROM `emissiontest` WHERE `ename`='$name'");
	$num=$stmt->rowCount();
	if($num>0){
		$row=$stmt->fetch(PDO::FETCH_ASSOC);
		$dbpassword=$row['password'];
		if(password_verify($password,$dbpassword)){
			$_SESSION['eid']=$row['e_id'];
		echo "<script>alert('Login Successfull');window.location='../emission.php';</script>";
		}else{
			echo "<script>alert('You have entered wrong password');window.location='../signin.php';</script>";

		}
	}else{
		// echo "<script>alert('You are not valid user');window.location='../signin.php';</script>";
} 

		// echo "<script>alert('You are not valid user');window.location='../signin.php';</script>";
	$stmt=$admin->ret("SELECT * FROM `traffic_police` WHERE `stname`='$name'");
	$num=$stmt->rowCount();
	if($num>0){
		$row=$stmt->fetch(PDO::FETCH_ASSOC);
		$dbpassword=$row['password'];
		if(password_verify($password,$dbpassword)){
			$_SESSION['pid']=$row['p_id'];
		echo "<script>alert('Login Successfull');window.location='../trafficpolice.php';</script>";
		}else{
			echo "<script>alert('You have entered wrong password');window.location='../signin.php';</script>";

		}
	}else{
		echo "<script>alert('You are not valid user');window.location='../signin.php';</script>";
}
}
	}
?>	