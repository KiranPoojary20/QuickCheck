<?php 
include '../config.php';
$admin=new Admin();
include '../../readerlib/qrlib.php';
$iid=$_SESSION['iid'];
if(isset($_POST['insurance'])){
    $bid=$_POST['bid'];
    $mid=$_POST['mid'];
    $cat_id=$_POST['category'];
    $regno=$_POST['regno'];
    $owner=$_POST['owner'];
    $email=$_POST['email'];
    $amount=$_POST['amount'];
    $date=$_POST['date'];
    $status='1 year paid';
    $stmt=$admin->ret("SELECT * FROM  `vehicle`   INNER JOIN `brand` ON brand.bid=vehicle.bid INNER JOIN `vehicle_category` ON vehicle_category.vc_id-vehicle.vc_id INNER JOIN `model` ON model.mid=vehicle.mid WHERE `oname`='$owner' AND `regno`='$regno'");
    $row=$stmt->fetch(PDO::FETCH_ASSOC);
    $num=$stmt->rowCount();
    if($num>0){
        $brand=$row['bname'];
        $model=$row['mname'];
        $cat_name=$row['vname'];
        $regnumber=$row['regno'];
        $regdate=$row['regdate'];
        $oname=$row['oname'];
        $ename=$row['ename'];
        $edate=$row['edate'];
        $estatus=$row['estatus'];
        
      $stmt2=$admin->ret("SELECT * FROM `insurance` WHERE `i_id`='$iid'");
      $row1=$stmt2->fetch(PDO::FETCH_ASSOC);
      $iname=$row1['iname'];
        $stmt1=$admin->cud("INSERT INTO `vinsurance`(`bid`, `mid`,`cat_id`,`i_id`, `oname`, `email`, `regno`, `idate`, `amount`, `status`) VALUES ('$bid','$mid','$cat_id','$iid','$owner','$email','$regno','$date','$amount','$status')",'inserted');


        $stmt3="brand:".$brand."\r\n"."model:".$model."\r\n"."category:".$cat_name."\r\n"."regno:".$regnumber."\r\n"."owner:".$oname."\r\n"."Insurance:".$iname."\r\n"."Insurance Amount:".$amount."\r\n"."Insurance date:".$date."\r\n"."Insurance Status:".$status."\r\n"."Emission:".$ename."\r\n"."Emission date:".$edate."\r\n"."Emission Status:".$estatus;


$qrImgName="qcode.rand()";

$qrs=QRcode::png($stmt3,"qcodes/$qrImgName.png","H","3","3 ");
$qrimage=$qrImgName.".png";
$stmt4=$admin -> cud("UPDATE `vehicle` SET `idate`='$date',`iamount`='$amount',`iname`='$iname',`istatus`='$status',`qrcode`='$qrimage' WHERE `regno`='$regno'","updated");
echo"<script>
alert('Inserted successfull');
window.location.href='../manage_insurance.php';
</script>";
    }else{
        echo"<script>
        alert('Please match the applicant current vechile registered username and register number');
        window.location.href='../manage_insurance.php';
      </script>";
    }
}
?>