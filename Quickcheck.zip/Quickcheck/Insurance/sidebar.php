 <nav class="navbar bg-secondary navbar-dark">
                <a href="index.html" class="navbar-brand mx-4 mb-3">
                    <h3 class="text-primary"><i class="fa fa-user-edit me-2"></i>QuickCheck</h3>
                </a>
                <div class="d-flex align-items-center ms-4 mb-4">
                    <div class="position-relative">
                        <img class="rounded-circle" src="img/q.png" alt="" style="width: 40px; height: 40px;"> 
                        <!-- <div class="bg-success rounded-circle border border-2 border-white position-absolute end-0 bottom-0 p-1"></div> -->
                    </div>
                    <div class="ms-3">
                       
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                           <?php 
                            if(isset($_SESSION['iid'])){
                    $iid=$_SESSION['iid'];
                    $stmt=$admin->ret("SELECT * FROM `insurance` WHERE `i_id`='$iid'");
                                $row=$stmt->fetch(PDO::FETCH_ASSOC);
?>
                           
                            <h6><?php echo $row['iname'] ?></h6>
                            <?php }elseif(isset($_SESSION['eid'])){
                     $eid=$_SESSION['eid'];
                    $stmt=$admin->ret("SELECT * FROM `emissiontest` WHERE `e_id`='$eid'");
                    $row=$stmt->fetch(PDO::FETCH_ASSOC);

                    ?>
                                                <h6><?php echo $row['ename'] ?></h6>
                                                <?php }elseif(isset($_SESSION['pid'])){
                     $eid=$_SESSION['pid'];
                    $stmt=$admin->ret("SELECT * FROM `traffic_police` WHERE `p_id`='$pid'");
                    $row=$stmt->fetch(PDO::FETCH_ASSOC);

                    ?>      
                                                <h6><?php echo $row['stname'] ?></h6>
<?php } ?>
                        </a>
                    </div>
                </div>
                <div class="navbar-nav w-100">
                    <a href="index.html" class="nav-item nav-link active"><i class="fa fa-tachometer-alt me-2"></i>Dashboard</a>
                    <?php 
                    if(isset($_SESSION['iid'])){
                    $iid=$_SESSION['iid'];
                    $stmt=$admin->ret("SELECT * FROM `insurance` WHERE `i_id`='$iid'");

?>
                    <a href="manage_insurance.php" class="nav-item nav-link "><i class="fa fa-tachometer-alt me-2"></i>Manage Insurance</a>
                    <a href="view_insurance.php" class="nav-item nav-link "><i class="fa fa-tachometer-alt me-2"></i>View Client</a>
                   <?php }elseif(isset($_SESSION['eid'])){
                     $eid=$_SESSION['eid'];
                    $stmt=$admin->ret("SELECT * FROM `emissiontest` WHERE `e_id`='$eid'");
                    ?>
                   <a href="manage_emission.php" class="nav-item nav-link "><i class="fa fa-tachometer-alt me-2"></i>Manage Emission</a>
                    <a href="view_emission.php" class="nav-item nav-link "><i class="fa fa-tachometer-alt me-2"></i>View Client</a>
                <?php }elseif(isset($_SESSION['pid'])){ ?>
                    <a href="manage_fine.php" class="nav-item nav-link "><i class="fa fa-tachometer-alt me-2"></i>Manage Fine</a>
                    <a href="view_user.php" class="nav-item nav-link "><i class="fa fa-tachometer-alt me-2"></i>View User</a>
                    <?php } ?>
                   
                   
                </div>
            </nav>