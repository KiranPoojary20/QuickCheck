<?php
include '../config.php';
$admin=new Admin();
if(isset($_POST['register'])){
$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$regno=$_POST['regno'];
$address=$_POST['address'];
$password=$_POST['password'];
$password=password_hash($password,PASSWORD_BCRYPT);


 $stmt=$admin->ret("SELECT * from `vehicle` WHERE `oname`='$name' AND `regno`='$regno'");
   $row = $stmt->fetch(PDO::FETCH_ASSOC);
   $num = $stmt->rowCount();
        if($num>0){
            
             $stmt = $admin -> cud("INSERT INTO `owner` ( `oname`, `regno`, `ophone`, `oemail`, `password`, `oaddress`) VALUES ('$name','$regno','$phone','$email','$password','$address')","saved");
  
    echo "<script>alert('Registerd Succesfull');window.location='../login.php';</script>";
}else{

    echo"<script>
             alert('please use your current vechile registered username and register number to login');
             window.location.href='../register.php';
           </script>";
}
}
?>