<?php
include '../config.php';
$admin = new Admin();
$oid = $_SESSION['oid'];

if (isset($_POST['update'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
  
    $address = $_POST['address'];

    $stmt = $admin->cud("UPDATE `owner` SET `oname`='$name', `ophone`='$phone', `oemail`='$email', `oaddress`='$address' WHERE `o_id`='$oid'", "updated");
  
    echo "<script>alert('Updated Successfully');window.location='../profile.php';</script>";
}
?>
