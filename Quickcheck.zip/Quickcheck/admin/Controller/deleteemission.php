<?php
include '../../config.php';
$admin=new Admin();
if(isset($_GET['eid'])){
	$eid=$_GET['eid'];
	$stmt=$admin->cud("DELETE FROM `emissiontest` WHERE `e_id`='$eid'",'Deleted');
	echo "<script>alert('Deleted Successfully');window.location='../viewemission.php'; </script>";
}
?>