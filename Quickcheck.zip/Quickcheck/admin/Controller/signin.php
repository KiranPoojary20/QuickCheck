<?php
include '../../config.php';
$admin=new Admin();
if(isset($_POST['signin'])){
	$name=$_POST['name'];
	$password=$_POST['password'];
	$stmt=$admin->ret("SELECT * FROM `admin` WHERE `aname`='$name'");
	$num=$stmt->rowCount();
	if($num>0){
		$row=$stmt->fetch(PDO::FETCH_ASSOC);
		$dbpassword=$row['password'];
		if(password_verify($password,$dbpassword)){
			$_SESSION['aid']=$row['a_id'];
		echo "<script>alert('Login Successfull');window.location='../index.php';</script>";
		}else{
			echo "<script>alert('You have entered wrong password');window.location='../signin.php';</script>";

		}
	}else{
		echo "<script>alert('You are not valid user');window.location='../signin.php';</script>";

	}
}
?>	