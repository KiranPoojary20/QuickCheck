<?php
include '../../config.php';
$admin=new Admin();
if(isset($_POST['trafficpolice'])){
	$pid=$_POST['pid'];
	$stname=$_POST['stname'];
	$pname=$_POST['pname'];
	$phone=$_POST['phone'];
	$email=$_POST['email'];
	$address=$_POST['address'];

	$stmt=$admin->cud("UPDATE `traffic_police` SET `stname`='$stname',`pname`='$pname',`phone`='$phone',`email`='$email',`address`='$address'WHERE `p_id`='$pid'",'Updated');
	echo "<script>alert('Updated Successfully');window.location='../viewtrafficpolice.php'; </script>";
}