<?php 
 include '../config.php';
 $admin=new Admin();
 if(isset($_POST['add_category'])){
 	$category=$_POST['category'];
 	$stmt=$admin->cud("INSERT INTO `vehicle_category` (`vname`)VALUES('$category')",'inserted');
   
 	echo "<script>alert('Category Added Successfull');window.location='../vehicle_registration.php';</script>"; 
 }

 if(isset($_POST['add_brand'])){
    $brand=$_POST['brand'];  
    $stmt1=$admin->ret("SELECT * FROM `brand` WHERE `bname`='$brand'");
    $num=$stmt1->rowCount();
    if($num>0){
        echo "<script>alert('Entered Brand name already exist');window.location='../vehicle_registration.php'; </script>";
    }else{
    $stmt=$admin->cud("INSERT INTO `brand` (`bname`)VALUES('$brand')",'inserted');
   
    echo "<script>alert('Brand Added Successfull');window.location='../vehicle_registration.php';</script>"; 
 }
}
if(isset($_POST['add_model'])){
    $bid=$_POST['bid'];
    $model=$_POST['mname'];
     $stmt2=$admin->ret("SELECT * FROM `model` WHERE `mname`='$model'");
    $num1=$stmt2->rowCount();
    if($num1>0){
        echo "<script>alert('Entered Model name already exist');window.location='../vehicle_registration.php';</script>";
    }else{
         $stmt=$admin->cud("INSERT INTO `model` (`bid`,`mname`)VALUES('$bid','$model')",'inserted');
    echo "<script>alert('Model Added Successfull');window.location='../vehicle_registration.php';</script>"; 
       }
 }
?>