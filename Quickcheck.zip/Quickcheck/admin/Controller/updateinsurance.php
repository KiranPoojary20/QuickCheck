<?php
include '../../config.php';
$admin=new Admin();
if(isset($_POST['insurance'])){
	$iid=$_POST['iid'];
	$name=$_POST['iname'];
	$uname=$_POST['iuname'];
	$phone=$_POST['phone'];
	$email=$_POST['email'];
	$address=$_POST['address'];
	$details=$_POST['details'];
	$stmt=$admin->cud("UPDATE `insurance` SET `iname`='$name',`iuname`='$uname',`phone`='$phone',`email`='$email',`address`='$address',`details`='$details' WHERE `i_id`='$iid'",'Updated');
	echo "<script>alert('Updated Successfully');window.location='../viewinsurance.php'; </script>";
}