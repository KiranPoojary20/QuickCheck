<?php
include '../../config.php';
$admin=new Admin();
if(isset($_POST['register'])){
	
	$name=$_POST['stname'];
	$pname=$_POST['pname'];
	$phone=$_POST['phone'];
	$email=$_POST['email'];
	$address=$_POST['address'];
	$password=$_POST['password'];
	$password=password_hash($password, PASSWORD_BCRYPT);
	$stmt=$admin->cud("INSERT INTO `traffic_police` (`stname`,`pname`,`phone`,`email`,`address`,`password`)VALUES('$name','$pname','$phone','$email','$address','$password')",'inserted');
	 echo "<script>alert('Registered Successfully');window.location='../insurance.php'; </script>";
}
?>