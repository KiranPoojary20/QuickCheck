<?php
include '../../config.php';
$admin=new Admin();
if(isset($_GET['iid'])){
	$iid=$_GET['iid'];
	$stmt=$admin->cud("DELETE FROM `insurance` WHERE `i_id`='$iid'",'Deleted');
	echo "<script>alert('Deleted Successfully');window.location='../viewinsurance.php'; </script>";
}
?>