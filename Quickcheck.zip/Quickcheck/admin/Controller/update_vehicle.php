<?php
include '../config.php';
$admin=new Admin();
if(isset($_POST['update'])){
	$vcid=$_POST['vcid'];
	$vname=$_POST['vehicle'];
	$stmt=$admin->cud("UPDATE `vehicle_category` SET `vname`='$vname' WHERE `vc_id`='$vcid' ",'updated');
	echo "<script>alert('Vehicle Category Updated Successfully');window.location='../registration.php';</script>";
}
if(isset($_POST['edit'])){
	$vbid=$_POST['bid'];
	$brname=$_POST['brname'];
	$stmt=$admin->cud("UPDATE `brand` SET `bname`='$brname' WHERE `bid`='$vbid' ",'updated');
	echo "<script>alert('Vehicle Brand Updated Successfully');window.location='../vehicle_registration.php';</script>";
}
if(isset($_POST['alter'])){
	$vmid=$_POST['mid'];
	$moname=$_POST['mname'];
	$stmt=$admin->cud("UPDATE `model` SET `mname`='$moname' WHERE `mid`='$vmid' ",'updated');
	echo "<script>alert('Vehicle Model Updated Successfully');window.location='../vehicle_registration.php';</script>";
}

?>