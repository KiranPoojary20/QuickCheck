<?php
include '../../config.php';
$admin=new Admin();
if(isset($_GET['pid'])){
	$pid=$_GET['pid'];
	$stmt=$admin->cud("DELETE FROM `traffic_police` WHERE `p_id`='$pid'",'Deleted');
	echo "<script>alert('Deleted Successfully');window.location='../viewtrafficpolice.php'; </script>";
}
?>