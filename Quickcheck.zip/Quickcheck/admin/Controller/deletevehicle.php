<?php
include '../../config.php';
$admin=new Admin();
if(isset($_GET['vid'])){
	$vid=$_GET['vid'];
	$stmt=$admin->cud("DELETE FROM `vehicle` WHERE `v_id`='$vid'",'Deleted');
	echo "<script>alert('Vehicle Deleted Successfully');window.location='../viewvehicle.php'; </script>";
}
if(isset($_GET['bid'])){
	$bid=$_GET['bid'];
	$stmt=$admin->cud("DELETE FROM `brand` WHERE `bid`='$bid'",'Deleted');
	echo "<script>alert('Brand Deleted Successfully');window.location='../vehicle_registration.php'; </script>";
}
if(isset($_GET['mid'])){
	$mid=$_GET['mid'];
	$stmt=$admin->cud("DELETE FROM `model` WHERE `mid`='$mid'",'Deleted');
	echo "<script>alert('Model Deleted Successfully');window.location='../vehicle_registration.php'; </script>";
}
if(isset($_GET['vcid'])){
	$vcid=$_GET['vcid'];
	$stmt=$admin->cud("DELETE FROM `vehicle_category` WHERE `vc_id`='$vcid'",'Deleted');
	echo "<script>alert('Vehicle Category Deleted Successfully');window.location='../registration.php'; </script>";
}
?>