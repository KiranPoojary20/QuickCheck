<?php
include '../../config.php';
$admin=new Admin();
include "../../readerlib/qrlib.php";
if(isset($_POST['register'])){
	$bid=$_POST['bid'];
	$mid=$_POST['mid'];
	$catid=$_POST['category'];
	$regno=$_POST['regno'];
	$owner=$_POST['owner'];
	$pid=$_POST['pid'];
	$date=$_POST['date'];


	$stmt2=$admin->ret("SELECT * FROM `brand` WHERE `bid`='$bid'");
	$row=$stmt2->fetch(PDO::FETCH_ASSOC);
	$brand=$row['bname'];
	$stmt3=$admin->ret("SELECT * FROM `model` WHERE `mid`='$mid'");
	$row1=$stmt3->fetch(PDO::FETCH_ASSOC);
	$model=$row1['mname'];
	$stmt4=$admin->ret("SELECT * FROM `vehicle_category` WHERE `vc_id`='$catid'");
	$row2=$stmt4->fetch(PDO::FETCH_ASSOC);
	$category=$row2['vname'];
	$stmt5=$admin->ret("SELECT * FROM `traffic_police` WHERE `p_id`='$pid'");
	$row3=$stmt5->fetch(PDO::FETCH_ASSOC);
	$police=$row3['stname'];
$stmt="brand:".$brand."\r\n"."model:".$model."\r\n"."category:".$category."\r\n"."regno:".$regno."\r\n"."owner:".$owner."\r\n"."police:".$police."\r\n"."date:".$date."\r\n";
$qrImgName="qcode.rand()";

$qrs=QRcode::png($stmt,"qcodes/$qrImgName.png","H","3","3 ");
$qrimage=$qrImgName.".png";
$stmt1=$admin->cud("INSERT INTO `vehicle`(`vc_id`,`bid`,`mid`,`regno`,`regdate`,`oname`,`p_id`,`qrcode`) VALUES('$catid','$bid','$mid','$regno','$date','$owner','$pid','$qrimage')","inserted");
echo "<script>alert('Vehicle Inserted Successfull');window.location='../registration.php';</script>";

}
?>
