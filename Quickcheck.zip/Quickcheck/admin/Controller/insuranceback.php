<?php
include '../../config.php';
$admin=new Admin();
if(isset($_POST['add'])){
	$name=$_POST['name'];
	$username=$_POST['uname'];
	$phone=$_POST['phone'];
	$email=$_POST['email'];
	$details=$_POST['details'];
	$address=$_POST['address'];
	$password=$_POST['password'];
	$password=password_hash($password, PASSWORD_BCRYPT); 
	 $stmt=$admin->cud("INSERT INTO `insurance` (`iname`,`iuname`,`phone`,`email`,`address`,`details`,`password`)VALUES('$name','$username','$phone','$email','$address','$details','$password')",'inserted');
	 echo "<script>alert('Registered Successfully');window.location='../trafficpolice.php'; </script>";
}
?>