<?php
include '../../config.php';
$admin=new Admin();
if(isset($_POST['register'])){
	$name=$_POST['name'];
	$username=$_POST['uname'];
	$email=$_POST['email'];
	$password=$_POST['password'];
	$phone=$_POST['phone'];
	$address=$_POST['address'];
	$detail=$_POST['detail'];
	$password=password_hash($password, PASSWORD_BCRYPT); 
	$stmt=$admin->cud("INSERT INTO `emissiontest` (`ename`,`euname`,`password`,`e_email`,`e_phone`,`e_address`,`e_details`)VALUES('$name','$username','$password','$email','$phone','$address','$detail')",'inserted');
	 echo "<script>alert('Registered Successfully');window.location='../emissiontest.php'; </script>";
}
?>
