<?php
include '../../config.php';
$admin=new Admin();
if(isset($_POST['emission'])){
	$eid=$_POST['eid'];
	$name=$_POST['ename'];
	$euname=$_POST['euname'];
	$phone=$_POST['ephone'];
	$email=$_POST['eemail'];
	$address=$_POST['eaddress'];
	$details=$_POST['edetails'];
	$stmt=$admin->cud("UPDATE `emissiontest` SET `ename`='$name',`euname`='$euname',`e_phone`='$phone',`e_email`='$email',`e_address`='$address',`e_details`='$details' WHERE `e_id`='$eid'",'Updated');
	echo "<script>alert('Updated Successfully');window.location='../viewemission.php'; </script>";
}
?>