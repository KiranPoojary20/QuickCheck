<?php 
include 'config.php';
$admin =new Admin();

$bid=$_GET['b_id'];

$stmt=$admin->ret("SELECT * FROM `model` WHERE `bid`='$bid' ");

while($row=$stmt->fetch(PDO::FETCH_ASSOC)){

    echo "<option value='".$row['mid']."'>".$row['mname']."</option>";
}


?>